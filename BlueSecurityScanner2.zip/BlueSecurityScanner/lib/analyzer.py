import os
import sys
import time
import logging
import random
from rich.console import Console
from rich.progress import Progress, TextColumn, BarColumn, TimeElapsedColumn
from rich.table import Table
import numpy as np

class SecurityAnalyzer:
    """
    Analyzes Bluetooth devices for security vulnerabilities and weaknesses (Simulation Mode)
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.console = Console()
        self.analysis_results = {}
        self.simulation_mode = True
        
    def analyze_device(self, device):
        """
        Perform comprehensive security analysis on target device
        
        Args:
            device (dict): Device information dictionary from scanner
        """
        addr = device['address']
        self.console.print(f"[bold blue]Analyzing security of {device['name']} ({addr})[/bold blue]")
        
        try:
            # Create analysis result structure
            if addr not in self.analysis_results:
                self.analysis_results[addr] = {
                    'device_info': device,
                    'timestamp': time.time(),
                    'analysis_complete': False,
                    'vulnerabilities': [],
                    'security_rating': 0,
                    'pin_security': {},
                    'encryption': {},
                    'authentication': {},
                    'l2cap_vulnerabilities': [],
                    'bluetooth5_features': {},
                    'ble_privacy': {},
                    'channel_hopping': {}
                }
                
            # Perform analysis with progress indication
            self._perform_analysis(device)
            
            # Mark analysis as complete
            self.analysis_results[addr]['analysis_complete'] = True
            
            # Display analysis summary
            self._display_analysis_summary(addr)
            
        except Exception as e:
            self.logger.error(f"Error in analyze_device: {str(e)}")
            self.console.print(f"[bold red]Error during analysis: {str(e)}[/bold red]")
        
    def _perform_analysis(self, device):
        """
        Internal method to perform the actual security analysis (Simulation Mode)
        
        Args:
            device (dict): Device information dictionary
        """
        addr = device['address']
        
        # Show progress for various analysis tasks
        with Progress(
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn()
        ) as progress:
            # PIN security analysis
            pin_task = progress.add_task("[cyan]Analyzing PIN security...", total=100)
            # Encryption analysis
            encryption_task = progress.add_task("[cyan]Analyzing encryption...", total=100, start=False)
            # Authentication analysis
            auth_task = progress.add_task("[cyan]Analyzing authentication...", total=100, start=False)
            # L2CAP vulnerability analysis
            l2cap_task = progress.add_task("[cyan]Checking L2CAP vulnerabilities...", total=100, start=False)
            # Overall security assessment
            security_task = progress.add_task("[cyan]Calculating security rating...", total=100, start=False)
            
            # Simulate analysis progress with realistic timings
            for i in range(100):
                if i == 99:  # Final step - record results
                    self.analysis_results[addr]['pin_security'] = self._analyze_pin_security(addr)
                progress.update(pin_task, advance=1)
                time.sleep(0.02)
                
            # Start encryption analysis
            progress.start_task(encryption_task)
            for i in range(100):
                if i == 99:  # Final step - record results
                    self.analysis_results[addr]['encryption'] = self._analyze_encryption(addr)
                progress.update(encryption_task, advance=1)
                time.sleep(0.02)
                
            # Start authentication analysis
            progress.start_task(auth_task)
            for i in range(100):
                if i == 99:  # Final step - record results
                    self.analysis_results[addr]['authentication'] = self._analyze_authentication(addr)
                progress.update(auth_task, advance=1)
                time.sleep(0.02)
                
            # Start L2CAP vulnerability check
            progress.start_task(l2cap_task)
            for i in range(100):
                if i == 99:  # Final step - record results
                    self.analysis_results[addr]['l2cap_vulnerabilities'] = self._check_l2cap_vulnerabilities(addr)
                progress.update(l2cap_task, advance=1)
                time.sleep(0.02)
                
            # Start security rating calculation
            progress.start_task(security_task)
            for i in range(100):
                if i == 99:  # Final step - calculate rating
                    # Identify vulnerabilities based on analysis results
                    vulnerabilities = self._identify_vulnerabilities(
                        device, 
                        self.analysis_results[addr]
                    )
                    self.analysis_results[addr]['vulnerabilities'] = vulnerabilities
                    
                    # Calculate overall security rating
                    security_rating = self._calculate_security_rating(self.analysis_results[addr])
                    self.analysis_results[addr]['security_rating'] = security_rating
                    
                progress.update(security_task, advance=1)
                time.sleep(0.01)
                
    def _analyze_pin_security(self, addr):
        """
        Analyze the PIN security of the target device (Simulation Mode)
        
        Args:
            addr (str): MAC address of the target device
            
        Returns:
            dict: PIN security assessment results
        """
        # In simulation mode, derive PIN security results from device MAC
        # This would involve actual PIN testing in a real implementation
        
        # Use MAC to seed random generator for consistent results per device
        seed = int(addr.replace(':', ''), 16) % 10000
        random.seed(seed)
        
        # Determine if common PINs are accepted
        common_pins_accepted = random.random() < 0.3  # 30% chance
        
        # Determine PIN complexity requirements
        pin_complexity = random.choice(["None", "Low", "Medium", "High"])
        
        # Determine minimum PIN length
        min_pin_length = random.choice([4, 4, 4, 6, 8])  # Weighted toward 4
        
        # Determine if device uses legacy pairing
        uses_legacy_pairing = random.random() < 0.4  # 40% chance
        
        # Determine if device supports Secure Simple Pairing (SSP)
        supports_ssp = random.random() < 0.6  # 60% chance
        
        # Reset random seed
        random.seed()
        
        # Create result dictionary
        result = {
            'common_pins_accepted': common_pins_accepted,
            'pin_complexity': pin_complexity,
            'min_pin_length': min_pin_length,
            'uses_legacy_pairing': uses_legacy_pairing,
            'supports_ssp': supports_ssp,
            'security_level': "Low" if common_pins_accepted or uses_legacy_pairing else
                              "Medium" if min_pin_length <= 4 else
                              "High"
        }
        
        return result
        
    def _analyze_encryption(self, addr):
        """
        Analyze the encryption capabilities of the target device (Simulation Mode)
        
        Args:
            addr (str): MAC address of the target device
            
        Returns:
            dict: Encryption analysis results
        """
        # In simulation mode, derive encryption results from device MAC
        # This would involve actual testing in a real implementation
        
        # Use MAC to seed random generator for consistent results per device
        seed = int(addr.replace(':', ''), 16) % 10000
        random.seed(seed)
        
        # Determine supported encryption types
        supports_e0 = random.random() < 0.5  # 50% chance (older encryption)
        supports_aes_ccm = random.random() < 0.7  # 70% chance (newer encryption)
        
        # Determine key sizes
        min_key_size = random.choice([8, 16, 16])  # bytes (weighted toward 16)
        max_key_size = min_key_size if random.random() < 0.5 else min(16, min_key_size + 8)
        
        # Determine if encryption is enforced
        encryption_enforced = random.random() < 0.6  # 60% chance
        
        # Reset random seed
        random.seed()
        
        # Create result dictionary
        result = {
            'supports_e0': supports_e0,
            'supports_aes_ccm': supports_aes_ccm,
            'min_key_size': min_key_size,
            'max_key_size': max_key_size,
            'encryption_enforced': encryption_enforced,
            'security_level': "Low" if (supports_e0 and not supports_aes_ccm) or min_key_size < 16 else
                              "Medium" if not encryption_enforced else
                              "High"
        }
        
        return result
        
    def _analyze_authentication(self, addr):
        """
        Analyze the authentication mechanisms of the target device (Simulation Mode)
        
        Args:
            addr (str): MAC address of the target device
            
        Returns:
            dict: Authentication analysis results
        """
        # In simulation mode, derive authentication results from device MAC
        # This would involve actual testing in a real implementation
        
        # Use MAC to seed random generator for consistent results per device
        seed = int(addr.replace(':', ''), 16) % 10000
        random.seed(seed)
        
        # Determine authentication capabilities
        supports_legacy_auth = random.random() < 0.4  # 40% chance
        supports_ssp = random.random() < 0.7  # 70% chance
        supports_oob = random.random() < 0.3  # 30% chance (Out of Band)
        supports_numeric_comparison = random.random() < 0.5  # 50% chance
        
        # Determine if MITM protection is present
        mitm_protection = random.random() < 0.6  # 60% chance
        
        # Determine if secure connections are supported (Bluetooth 4.2+)
        secure_connections = random.random() < 0.5  # 50% chance
        
        # Reset random seed
        random.seed()
        
        # Create result dictionary
        result = {
            'supports_legacy_auth': supports_legacy_auth,
            'supports_ssp': supports_ssp,
            'supports_oob': supports_oob,
            'supports_numeric_comparison': supports_numeric_comparison,
            'mitm_protection': mitm_protection,
            'secure_connections': secure_connections,
            'security_level': "Low" if supports_legacy_auth and not mitm_protection else
                              "Medium" if not secure_connections else
                              "High"
        }
        
        return result
        
    def _check_l2cap_vulnerabilities(self, addr):
        """
        Check for L2CAP vulnerabilities in the target device (Simulation Mode)
        
        Args:
            addr (str): MAC address of the target device
            
        Returns:
            list: Discovered L2CAP vulnerabilities
        """
        # In simulation mode, derive vulnerabilities from device MAC
        # This would involve actual vulnerability testing in a real implementation
        
        # Use MAC to seed random generator for consistent results per device
        seed = int(addr.replace(':', ''), 16) % 10000
        random.seed(seed)
        
        vulnerabilities = []
        
        # Check for buffer overflow vulnerability (more likely on older devices)
        if random.random() < 0.2:  # 20% chance
            vulnerabilities.append({
                'name': 'L2CAP Buffer Overflow',
                'severity': 'High',
                'description': 'Device is vulnerable to buffer overflow attacks through malformed L2CAP packets',
                'cve_reference': 'CVE-2017-0781'
            })
            
        # Check for ping flood vulnerability (common)
        if random.random() < 0.3:  # 30% chance
            vulnerabilities.append({
                'name': 'L2CAP Ping Flood',
                'severity': 'Medium',
                'description': 'Device is vulnerable to denial of service through excessive L2CAP echo requests',
                'cve_reference': 'CVE-2018-9358'
            })
            
        # Check for fragmentation vulnerability
        if random.random() < 0.15:  # 15% chance
            vulnerabilities.append({
                'name': 'L2CAP Fragmentation',
                'severity': 'Medium',
                'description': 'Device improperly handles fragmented L2CAP packets which may lead to crashes',
                'cve_reference': 'CVE-2019-9506'
            })
            
        # Check for Key Negotiation vulnerability (Bluetooth 5.0 and earlier)
        if random.random() < 0.25:  # 25% chance
            vulnerabilities.append({
                'name': 'KNOB Attack',
                'severity': 'High',
                'description': 'Device is vulnerable to Key Negotiation of Bluetooth (KNOB) attack',
                'cve_reference': 'CVE-2019-9506'
            })
            
        # Reset random seed
        random.seed()
        
        return vulnerabilities
        
    def _identify_vulnerabilities(self, device, results):
        """
        Identify specific vulnerabilities based on the analysis results (Simulation Mode)
        
        Args:
            device (dict): Device information
            results (dict): Analysis results
            
        Returns:
            list: Discovered vulnerabilities
        """
        vulnerabilities = []
        
        # Check PIN security vulnerabilities
        pin_security = results.get('pin_security', {})
        if pin_security.get('common_pins_accepted', False):
            vulnerabilities.append({
                'category': 'PIN Security',
                'name': 'Common PIN Acceptance',
                'severity': 'High',
                'description': 'Device accepts common PIN codes, making it vulnerable to brute force attacks',
                'recommendation': 'Use a unique PIN that is not commonly used'
            })
            
        if pin_security.get('uses_legacy_pairing', False):
            vulnerabilities.append({
                'category': 'PIN Security',
                'name': 'Legacy Pairing',
                'severity': 'High',
                'description': 'Device uses legacy pairing which is vulnerable to MITM attacks',
                'recommendation': 'Use a device that supports Secure Simple Pairing (SSP)'
            })
            
        # Check encryption vulnerabilities
        encryption = results.get('encryption', {})
        if encryption.get('supports_e0', False) and not encryption.get('supports_aes_ccm', False):
            vulnerabilities.append({
                'category': 'Encryption',
                'name': 'Weak Encryption',
                'severity': 'High',
                'description': 'Device uses E0 stream cipher which is cryptographically weak',
                'recommendation': 'Use a device that supports AES-CCM encryption'
            })
            
        if not encryption.get('encryption_enforced', True):
            vulnerabilities.append({
                'category': 'Encryption',
                'name': 'Optional Encryption',
                'severity': 'Medium',
                'description': 'Device does not enforce encryption for all communications',
                'recommendation': 'Configure device to require encryption for all connections'
            })
            
        # Check authentication vulnerabilities
        authentication = results.get('authentication', {})
        if authentication.get('supports_legacy_auth', False) and not authentication.get('mitm_protection', False):
            vulnerabilities.append({
                'category': 'Authentication',
                'name': 'MITM Vulnerability',
                'severity': 'High',
                'description': 'Device is vulnerable to Man-in-the-Middle attacks during pairing',
                'recommendation': 'Use a device that supports MITM protection'
            })
            
        # Include any L2CAP vulnerabilities
        for vuln in results.get('l2cap_vulnerabilities', []):
            vulnerabilities.append({
                'category': 'L2CAP',
                'name': vuln.get('name'),
                'severity': vuln.get('severity'),
                'description': vuln.get('description'),
                'cve_reference': vuln.get('cve_reference'),
                'recommendation': 'Update device firmware or replace with a more secure model'
            })
            
        # Check protocol version vulnerabilities
        if 'protocol_version' in device:
            version = device['protocol_version']
            if version in ["4.0", "4.1"]:
                vulnerabilities.append({
                    'category': 'Protocol',
                    'name': 'Outdated Protocol',
                    'severity': 'Medium',
                    'description': f'Device uses Bluetooth {version} which has known security weaknesses',
                    'recommendation': 'Use a device with Bluetooth 4.2 or newer'
                })
                
        return vulnerabilities
        
    def _calculate_security_rating(self, results):
        """
        Calculate overall security rating based on analysis results (Simulation Mode)
        
        Args:
            results (dict): Analysis results
            
        Returns:
            float: Security rating (1-10, higher is more secure)
        """
        # Start with middle rating
        rating = 5.0
        
        # Adjust for PIN security
        pin_security = results.get('pin_security', {})
        if pin_security.get('security_level') == "Low":
            rating -= 1.5
        elif pin_security.get('security_level') == "High":
            rating += 1.0
            
        # Adjust for encryption
        encryption = results.get('encryption', {})
        if encryption.get('security_level') == "Low":
            rating -= 1.5
        elif encryption.get('security_level') == "High":
            rating += 1.0
            
        # Adjust for authentication
        authentication = results.get('authentication', {})
        if authentication.get('security_level') == "Low":
            rating -= 1.5
        elif authentication.get('security_level') == "High":
            rating += 1.0
            
        # Adjust for L2CAP vulnerabilities
        l2cap_vulns = results.get('l2cap_vulnerabilities', [])
        for vuln in l2cap_vulns:
            if vuln.get('severity') == "High":
                rating -= 1.0
            elif vuln.get('severity') == "Medium":
                rating -= 0.5
                
        # Ensure rating is within range 1-10
        return max(1.0, min(10.0, rating))
        
    def _display_analysis_summary(self, addr):
        """
        Display a summary of the security analysis results
        
        Args:
            addr (str): MAC address of the analyzed device
        """
        if addr not in self.analysis_results or not self.analysis_results[addr]['analysis_complete']:
            self.console.print("[yellow]Analysis not complete for this device[/yellow]")
            return
            
        results = self.analysis_results[addr]
        device = results['device_info']
        
        # Determine security rating color
        rating = results['security_rating']
        if rating >= 7.0:
            rating_color = "green"
        elif rating >= 4.0:
            rating_color = "yellow"
        else:
            rating_color = "red"
            
        # Display summary panel
        self.console.print("\n[bold]Security Analysis Summary[/bold]")
        self.console.print(f"Device: {device['name']} ({addr})")
        self.console.print(f"Protocol Version: {device.get('protocol_version', 'Unknown')}")
        self.console.print(f"Manufacturer: {device.get('manufacturer', 'Unknown')}")
        self.console.print(f"Security Rating: [{rating_color}]{rating:.1f}/10[/{rating_color}]")
        
        # Display vulnerabilities if found
        if results['vulnerabilities']:
            self.console.print(f"\n[bold red]Vulnerabilities Found: {len(results['vulnerabilities'])}[/bold red]")
            
            table = Table(title="Security Vulnerabilities")
            table.add_column("Category", style="cyan")
            table.add_column("Vulnerability", style="red")
            table.add_column("Severity", style="yellow")
            table.add_column("Description")
            
            for vuln in results['vulnerabilities']:
                severity_color = "red" if vuln['severity'] == "High" else "yellow" if vuln['severity'] == "Medium" else "green"
                
                table.add_row(
                    vuln['category'],
                    vuln['name'],
                    f"[{severity_color}]{vuln['severity']}[/{severity_color}]",
                    vuln['description']
                )
                
            self.console.print(table)
            
            # Display recommendations
            self.console.print("\n[bold yellow]Security Recommendations:[/bold yellow]")
            for i, vuln in enumerate(results['vulnerabilities']):
                if 'recommendation' in vuln:
                    self.console.print(f"{i+1}. {vuln['recommendation']}")
        else:
            self.console.print("\n[bold green]No vulnerabilities detected[/bold green]")