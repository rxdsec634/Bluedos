"""
Cross-platform compatibility layer for the Bluetooth Security Toolkit
Ensures consistent behavior across Windows, macOS, and Linux
"""

import os
import sys
import platform
import subprocess
from colorama import init, Fore, Back, Style

# Initialize colorama for Windows compatibility
init(autoreset=True)

def is_windows():
    """
    Check if the current platform is Windows
    
    Returns:
        bool: True if Windows, False otherwise
    """
    return platform.system() == "Windows"

def is_admin():
    """
    Check if running with administrator/root privileges
    
    Returns:
        bool: True if running with elevated privileges, False otherwise
    """
    try:
        if is_windows():
            # On Windows, check if the script is running as administrator
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        else:
            # On Unix-like systems, check if effective user ID is 0 (root)
            return os.geteuid() == 0
    except Exception:
        # If there's an error or we're in an environment where we can't check,
        # we'll assume we have sufficient privileges
        return True

def clear_screen():
    """
    Clear the terminal screen in a cross-platform way
    """
    if is_windows():
        os.system('cls')
    else:
        os.system('clear')

def get_terminal_size():
    """
    Get terminal size in a cross-platform way
    
    Returns:
        tuple: (width, height) of the terminal
    """
    try:
        # Try using os.get_terminal_size() on Python 3
        return os.get_terminal_size()
    except:
        # Fallback to default values
        return (80, 24)

def set_console_title(title):
    """
    Set console window title in a cross-platform way
    
    Args:
        title (str): The title to set
    """
    if is_windows():
        # Windows uses a different command to set console title
        os.system(f'title {title}')
    else:
        # ANSI escape sequence to set terminal title
        sys.stdout.write(f"\033]0;{title}\007")
        sys.stdout.flush()

def format_text(text, color=None, bright=False, background=None):
    """
    Format text with color in a cross-platform way
    
    Args:
        text (str): The text to format
        color (str): Color name ('red', 'green', 'blue', 'yellow', 'magenta', 'cyan', 'white', 'black')
        bright (bool): Whether to use bright/bold version of the color
        background (str): Background color name
    
    Returns:
        str: The formatted text with ANSI color codes
    """
    result = ""
    
    # Set style (bright/bold)
    if bright:
        result += Style.BRIGHT
    
    # Set foreground color
    if color:
        color = color.lower()
        if color == 'red':
            result += Fore.RED
        elif color == 'green':
            result += Fore.GREEN
        elif color == 'blue':
            result += Fore.BLUE
        elif color == 'yellow':
            result += Fore.YELLOW
        elif color == 'magenta':
            result += Fore.MAGENTA
        elif color == 'cyan':
            result += Fore.CYAN
        elif color == 'white':
            result += Fore.WHITE
        elif color == 'black':
            result += Fore.BLACK
    
    # Set background color
    if background:
        background = background.lower()
        if background == 'red':
            result += Back.RED
        elif background == 'green':
            result += Back.GREEN
        elif background == 'blue':
            result += Back.BLUE
        elif background == 'yellow':
            result += Back.YELLOW
        elif background == 'magenta':
            result += Back.MAGENTA
        elif background == 'cyan':
            result += Back.CYAN
        elif background == 'white':
            result += Back.WHITE
        elif background == 'black':
            result += Back.BLACK
    
    # Add the actual text and reset all formatting
    result += text + Style.RESET_ALL
    
    return result

def get_supported_box_chars():
    """
    Get box drawing characters that are supported by the current terminal
    
    Returns:
        dict: A dictionary of box drawing characters
    """
    if is_windows():
        # Use simple ASCII characters on Windows CMD
        # (unless we detect Windows Terminal which supports Unicode)
        term = os.environ.get('WT_SESSION', '')
        if not term:  # If not Windows Terminal
            return {
                'horizontal': '-',
                'vertical': '|',
                'top_left': '+',
                'top_right': '+',
                'bottom_left': '+',
                'bottom_right': '+',
                'left_t': '+',
                'right_t': '+',
                'top_t': '+',
                'bottom_t': '+',
                'cross': '+'
            }
    
    # For terminals that support Unicode box drawing
    return {
        'horizontal': '═',
        'vertical': '║',
        'top_left': '╔',
        'top_right': '╗',
        'bottom_left': '╚',
        'bottom_right': '╝',
        'left_t': '╠',
        'right_t': '╣',
        'top_t': '╦',
        'bottom_t': '╩',
        'cross': '╬'
    }

def get_bluetooth_service_status():
    """
    Check if Bluetooth service is running in a cross-platform way
    
    Returns:
        bool: True if Bluetooth service is running, False otherwise
    """
    system = platform.system()
    
    try:
        if system == "Windows":
            # Check if Bluetooth service is running on Windows
            result = subprocess.run(
                ["sc", "query", "bthserv"], 
                capture_output=True, 
                text=True
            )
            return "RUNNING" in result.stdout
            
        elif system == "Linux":
            # Check if Bluetooth service is running on Linux
            result = subprocess.run(
                ["systemctl", "is-active", "bluetooth"], 
                capture_output=True, 
                text=True
            )
            return "active" in result.stdout
            
        elif system == "Darwin":  # macOS
            # Check if Bluetooth is available on macOS
            result = subprocess.run(
                ["system_profiler", "SPBluetoothDataType"], 
                capture_output=True, 
                text=True
            )
            return "Bluetooth Low Energy" in result.stdout or "Bluetooth:" in result.stdout
            
        # If we can't determine, assume it's working
        return True
        
    except Exception:
        # If we can't check, assume it's working
        return True

def start_bluetooth_service():
    """
    Try to start the Bluetooth service in a cross-platform way
    
    Returns:
        bool: True if the service was started successfully, False otherwise
    """
    system = platform.system()
    
    try:
        if system == "Windows":
            # Start Bluetooth service on Windows
            subprocess.run(["sc", "start", "bthserv"], check=False)
            # Check if it's now running
            return get_bluetooth_service_status()
            
        elif system == "Linux":
            # Start Bluetooth service on Linux
            subprocess.run(["systemctl", "start", "bluetooth"], check=False)
            # Check if it's now running
            return get_bluetooth_service_status()
            
        elif system == "Darwin":  # macOS
            # On macOS, we can't easily start/stop Bluetooth from command line
            # Just check if it's available
            return get_bluetooth_service_status()
            
        # If we can't determine, assume it worked
        return True
        
    except Exception:
        # If we can't start it, assume it failed
        return False