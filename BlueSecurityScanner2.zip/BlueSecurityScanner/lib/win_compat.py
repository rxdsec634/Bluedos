"""
Windows-specific compatibility layer for the Bluetooth Security Toolkit
"""

import os
import sys
import platform
from colorama import init, Fore, Back, Style

# Initialize colorama for Windows compatibility
init(autoreset=True)

def is_windows():
    """
    Check if the current platform is Windows
    
    Returns:
        bool: True if Windows, False otherwise
    """
    return platform.system() == "Windows"

def is_windows_terminal():
    """
    Check if running in Windows Terminal (modern terminal with better Unicode support)
    
    Returns:
        bool: True if Windows Terminal, False otherwise
    """
    return os.environ.get('WT_SESSION', '') != ''

def can_use_unicode():
    """
    Check if the terminal supports Unicode box drawing characters
    
    Returns:
        bool: True if Unicode is supported, False otherwise
    """
    # Windows Terminal supports Unicode, classic CMD does not
    if is_windows() and not is_windows_terminal():
        return False
    return True

def get_box_chars():
    """
    Get box drawing characters appropriate for the current terminal
    
    Returns:
        dict: Dictionary of box drawing characters
    """
    if can_use_unicode():
        return {
            'horizontal': '═',
            'vertical': '║',
            'top_left': '╔',
            'top_right': '╗',
            'bottom_left': '╚',
            'bottom_right': '╝',
            'left_t': '╠',
            'right_t': '╣',
            'top_t': '╦',
            'bottom_t': '╩',
            'cross': '╬'
        }
    else:
        # ASCII box drawing for Windows CMD
        return {
            'horizontal': '-',
            'vertical': '|',
            'top_left': '+',
            'top_right': '+',
            'bottom_left': '+',
            'bottom_right': '+',
            'left_t': '+',
            'right_t': '+',
            'top_t': '+',
            'bottom_t': '+',
            'cross': '+'
        }

def draw_custom_box(title, content, width=80):
    """
    Draw a box with title and content using the appropriate box characters
    
    Args:
        title (str): Box title
        content (str): Box content
        width (int): Box width
    
    Returns:
        str: Box as a string
    """
    box = get_box_chars()
    result = []
    
    # Adjust width if necessary
    title_len = len(title)
    if title_len + 4 > width:
        width = title_len + 4
    
    # Top border with title
    result.append(f"{box['top_left']}{box['horizontal']}{title}{box['horizontal'] * (width - title_len - 2)}{box['top_right']}")
    
    # Content
    for line in content.split('\n'):
        # Pad or truncate line to fit width
        if len(line) > width - 2:
            padded_line = line[:width - 5] + "..."
        else:
            padded_line = line + " " * (width - len(line) - 2)
        result.append(f"{box['vertical']} {padded_line} {box['vertical']}")
    
    # Bottom border
    result.append(f"{box['bottom_left']}{box['horizontal'] * (width - 2)}{box['bottom_right']}")
    
    return '\n'.join(result)

def format_for_cmd(text, use_fallback=False):
    """
    Format text with appropriate encoding for Windows CMD
    
    Args:
        text (str): The text to format
        use_fallback (bool): Whether to replace Unicode with ASCII if needed
    
    Returns:
        str: The formatted text
    """
    if is_windows() and not is_windows_terminal() and use_fallback:
        # Replace common Unicode characters with ASCII equivalents
        replacements = {
            '═': '-',
            '║': '|',
            '╔': '+',
            '╗': '+',
            '╚': '+',
            '╝': '+',
            '╠': '+',
            '╣': '+',
            '╦': '+',
            '╩': '+',
            '╬': '+',
            '✓': 'v',
            '→': '->',
            '⚠': '!',
            '⚡': '!'
        }
        for unicode_char, ascii_char in replacements.items():
            text = text.replace(unicode_char, ascii_char)
    
    return text

def set_console_title(title):
    """
    Set the console title on Windows
    
    Args:
        title (str): The title to set
    """
    if is_windows():
        os.system(f'title {title}')
    else:
        # ANSI escape sequence for Unix-like systems
        print(f'\033]0;{title}\007', end='')

def clear_screen():
    """
    Clear the console screen
    """
    os.system('cls' if is_windows() else 'clear')