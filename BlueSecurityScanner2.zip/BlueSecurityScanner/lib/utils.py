import os
import sys
import time
import logging
import random
import platform
import subprocess
from colorama import init, Fore, Back, Style

# Initialize colorama for Windows compatibility
init(autoreset=True)

def setup_logging(log_level=logging.INFO, log_file=None):
    """
    Set up logging configuration
    
    Args:
        log_level: Logging level (default: INFO)
        log_file: Path to log file (default: None)
    """
    # Create logs directory if it doesn't exist and log_file is specified
    if log_file:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
    # Configure logging
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    handlers = []
    
    if log_file:
        handlers.append(logging.FileHandler(log_file))
        
    handlers.append(logging.StreamHandler())
    
    logging.basicConfig(
        level=log_level,
        format=log_format,
        handlers=handlers
    )
    
    logger = logging.getLogger(__name__)
    logger.info("Logging initialized")
    
def check_root_privileges():
    """
    Check if the script is running with root/administrator privileges
    
    Returns:
        bool: True if running with elevated privileges, False otherwise
    """
    try:
        # Check based on operating system
        if platform.system() == "Windows":
            # On Windows, check if the script is running as administrator
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        else:
            # On Unix-like systems, check if effective user ID is 0 (root)
            return os.geteuid() == 0
    except:
        # If there's an error or we're in an environment where we can't check,
        # we'll assume we have sufficient privileges
        return True
        
def check_bluetooth_service():
    """
    Check if Bluetooth service is running and try to start it if not
    
    Returns:
        bool: True if Bluetooth service is running, False otherwise
    """
    try:
        system = platform.system()
        
        if system == "Linux":
            # Check if Bluetooth service is running on Linux
            result = subprocess.run(
                ["systemctl", "is-active", "bluetooth"], 
                capture_output=True, 
                text=True
            )
            if "active" in result.stdout:
                return True
            else:
                # Try to start the service
                subprocess.run(["systemctl", "start", "bluetooth"], check=False)
                # Check again
                result = subprocess.run(
                    ["systemctl", "is-active", "bluetooth"], 
                    capture_output=True, 
                    text=True
                )
                return "active" in result.stdout
                
        elif system == "Windows":
            # Check if Bluetooth service is running on Windows
            result = subprocess.run(
                ["sc", "query", "bthserv"], 
                capture_output=True, 
                text=True
            )
            if "RUNNING" in result.stdout:
                return True
            else:
                # Try to start the service
                subprocess.run(["sc", "start", "bthserv"], check=False)
                # Check again
                result = subprocess.run(
                    ["sc", "query", "bthserv"], 
                    capture_output=True, 
                    text=True
                )
                return "RUNNING" in result.stdout
                
        elif system == "Darwin":  # macOS
            # Check if Bluetooth is available on macOS
            result = subprocess.run(
                ["system_profiler", "SPBluetoothDataType"], 
                capture_output=True, 
                text=True
            )
            return "Bluetooth Low Energy" in result.stdout or "Bluetooth:" in result.stdout
            
        # If we can't determine, assume it's working
        return True
        
    except Exception as e:
        logging.warning(f"Error checking Bluetooth service: {e}")
        # If we can't check, assume it's working
        return True
    
def print_banner():
    """
    Print a fancy banner for the tool
    """
    print(Fore.RED, end="")  # Red color for the banner
    banner = """
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║   ██████╗ ██╗  ██╗██████╗  ███████╗███████╗ ██████╗                      ║
║   ██╔══██╗╚██╗██╔╝██╔══██╗ ██╔════╝██╔════╝██╔════╝                      ║
║   ██████╔╝ ╚███╔╝ ██║  ██║ ███████╗█████╗  ██║                           ║
║   ██╔══██╗ ██╔██╗ ██║  ██║ ╚════██║██╔══╝  ██║                           ║
║   ██║  ██║██╔╝ ██╗██████╔╝ ███████║███████╗╚██████╗                      ║
║   ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝  ╚══════╝╚══════╝ ╚═════╝                      ║
║                                                                           ║
║      """ + Style.BRIGHT + Fore.WHITE + """███████╗███████╗ ██████╗   ███████╗ ██████╗ █████╗ ███╗   ██╗""" + Style.RESET_ALL + Fore.RED + """        ║
║      """ + Style.BRIGHT + Fore.WHITE + """██╔════╝██╔════╝██╔════╝   ██╔════╝██╔════╝██╔══██╗████╗  ██║""" + Style.RESET_ALL + Fore.RED + """        ║
║      """ + Style.BRIGHT + Fore.WHITE + """███████╗█████╗  ██║        ███████╗██║     ███████║██╔██╗ ██║""" + Style.RESET_ALL + Fore.RED + """        ║
║      """ + Style.BRIGHT + Fore.WHITE + """╚════██║██╔══╝  ██║        ╚════██║██║     ██╔══██║██║╚██╗██║""" + Style.RESET_ALL + Fore.RED + """        ║
║      """ + Style.BRIGHT + Fore.WHITE + """███████║███████╗╚██████╗██╗███████║╚██████╗██║  ██║██║ ╚████║""" + Style.RESET_ALL + Fore.RED + """        ║
║      """ + Style.BRIGHT + Fore.WHITE + """╚══════╝╚══════╝ ╚═════╝╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝""" + Style.RESET_ALL + Fore.RED + """        ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
    """
    print(banner)
    print(Style.BRIGHT + Fore.WHITE + "RXDSEC BT VULNERABILITY SCANNER - ADVANCED EXPLOITATION TOOLKIT" + Style.RESET_ALL)
    print(Fore.RED + "=== HIGH-PERFORMANCE BLUETOOTH 5.0/5.3 ATTACK PLATFORM ===" + Style.RESET_ALL)
    print(Fore.BLUE + "[ Real-Time Device Detection | Security Analysis | DoS Capability ]" + Style.RESET_ALL)
    print(Fore.YELLOW + "v2.0 - Created by @Rxdsec" + Style.RESET_ALL)
    print(Fore.RED + "======================================================" + Style.RESET_ALL)
    
def print_warning(message):
    """
    Print a warning message
    
    Args:
        message (str): Warning message to display
    """
    print(f"{Fore.YELLOW}[!] Warning: {message}{Style.RESET_ALL}")
    
def print_error(message):
    """
    Print an error message
    
    Args:
        message (str): Error message to display
    """
    print(f"{Fore.RED}[!] Error: {message}{Style.RESET_ALL}")
    
def print_info(message):
    """
    Print an informational message
    
    Args:
        message (str): Info message to display
    """
    print(f"{Fore.BLUE}[*] {message}{Style.RESET_ALL}")
    
def generate_random_mac():
    """
    Generate a random MAC address
    
    Returns:
        str: Random MAC address
    """
    mac = [random.randint(0, 255) for _ in range(6)]
    return ':'.join([f'{x:02x}' for x in mac])
    
def mac_to_int(mac):
    """
    Convert a MAC address to integer
    
    Args:
        mac (str): MAC address
        
    Returns:
        int: Integer representation of MAC address
    """
    return int(mac.replace(':', ''), 16)
    
def get_vendor_from_mac(mac):
    """
    Get vendor name from MAC address OUI
    
    Args:
        mac (str): MAC address
        
    Returns:
        str: Vendor name or Unknown
    """
    # Common vendor OUI prefixes (first 3 bytes of MAC)
    oui_map = {
        "00:0d:93": "Apple",
        "00:1c:b3": "Apple",
        "00:3e:e1": "Apple",
        "00:a0:40": "Apple",
        "34:c7:31": "Apple",
        "00:15:99": "Samsung",
        "00:17:d5": "Samsung",
        "00:21:19": "Samsung",
        "00:23:39": "Samsung",
        "00:25:38": "Samsung",
        "00:0c:8a": "Bose",
        "04:52:c7": "Bose",
        "08:df:1f": "Bose",
        "00:01:4a": "Sony",
        "00:13:a9": "Sony",
        "00:18:13": "Sony",
        "00:24:be": "Sony",
        "00:22:45": "Fitbit",
        "e8:43:b6": "Fitbit",
        "00:03:ff": "Microsoft",
        "00:12:5a": "Microsoft",
        "00:17:fa": "Microsoft",
        "00:50:f2": "Microsoft",
        "00:1a:11": "Google",
        "3c:5a:b4": "Google",
        "f4:f5:d8": "Google",
        "00:0e:8f": "Sercomm",
        "00:02:02": "Spectrum",
        "00:0a:95": "Apple",
        "00:05:02": "Apple",
        "00:07:e9": "Intel",
        "00:0c:29": "VMware",
        "b8:27:eb": "Raspberry Pi"
    }
    
    prefix = mac[:8].lower()
    return oui_map.get(prefix, "Unknown")