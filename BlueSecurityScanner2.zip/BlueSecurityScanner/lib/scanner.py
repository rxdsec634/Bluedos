import os
import sys
import time
import logging
import threading
import asyncio
import random
from bleak import BleakScanner, BLEDevice
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

class BluetoothScanner:
    """
    Handles scanning for Bluetooth devices and service discovery using real Bluetooth hardware
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.discovered_devices = []
        self.scanning_active = False
        self.console = Console()
        self.loop = None
        
    def scan_devices(self, duration=5, advanced=True):
        """
        Scan for nearby Bluetooth devices using BLE
        
        Args:
            duration (int): Scan duration in seconds
            advanced (bool): Whether to perform advanced service discovery
        """
        try:
            self.scanning_active = True
            self.discovered_devices = []
            
            # Create or get event loop
            try:
                self.loop = asyncio.get_event_loop()
            except RuntimeError:
                self.loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self.loop)
            
            # Run the async scan in the event loop
            self.console.print(Panel("[bold green]Starting Real-Time Bluetooth Scan[/bold green]", 
                                    subtitle="RXDSEC Security Scanner"))
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[bold blue]{task.description}[/bold blue]"),
                TimeElapsedColumn(),
                console=self.console
            ) as progress:
                task = progress.add_task("[bold red]Scanning for vulnerable BT devices...", total=None)
                # Run the async scan
                self.loop.run_until_complete(self._async_scan(duration, advanced, progress))
                progress.update(task, completed=True)
            
            if not self.discovered_devices:
                self.console.print("[bold red]No Bluetooth devices found![/bold red]")
            else:
                self.console.print(f"[bold green]Found {len(self.discovered_devices)} Bluetooth devices[/bold green]")
                self._display_devices()
                
        except Exception as e:
            self.logger.error(f"Error in scan_devices: {str(e)}")
            self.console.print(f"[bold red]Error: {str(e)}[/bold red]")
        finally:
            self.scanning_active = False
            
    async def _async_scan(self, duration, advanced, progress=None):
        """
        Perform asynchronous Bluetooth scan using bleak
        
        Args:
            duration (int): Scan duration in seconds
            advanced (bool): Whether to perform advanced service discovery
            progress (Progress, optional): Progress object for updates
        """
        try:
            # Update the progress description
            if progress and hasattr(progress, 'tasks') and progress.tasks:
                # Check if tasks is a dictionary with keys
                if isinstance(progress.tasks, dict) and progress.tasks:
                    task_ids = list(progress.tasks.keys())
                    if task_ids:  # Make sure the list is not empty
                        task_id = task_ids[0]
                        progress.update(task_id, description="[bold blue]Initializing Bluetooth scanner...[/bold blue]")
                # Handle case where tasks is a list
                elif isinstance(progress.tasks, list) and len(progress.tasks) > 0:
                    task_id = progress.tasks[0].id
                    progress.update(task_id, description="[bold blue]Initializing Bluetooth scanner...[/bold blue]")
                
            # Start the BLE scan
            scanner = BleakScanner()
            
            if progress and hasattr(progress, 'tasks') and progress.tasks:
                # Handle different progress.tasks types
                if isinstance(progress.tasks, dict) and progress.tasks:
                    task_ids = list(progress.tasks.keys())
                    if task_ids:  # Make sure the list is not empty
                        task_id = task_ids[0]
                        progress.update(task_id, description="[bold blue]Scanning for Bluetooth devices...[/bold blue]")
                elif isinstance(progress.tasks, list) and len(progress.tasks) > 0:
                    task_id = progress.tasks[0].id
                    progress.update(task_id, description="[bold blue]Scanning for Bluetooth devices...[/bold blue]")
            
            # Run the scan with the specified duration
            discovered = await scanner.discover(timeout=duration)
            
            if progress and hasattr(progress, 'tasks') and progress.tasks:
                # Handle different progress.tasks types
                if isinstance(progress.tasks, dict) and progress.tasks:
                    task_ids = list(progress.tasks.keys())
                    if task_ids:  # Make sure the list is not empty
                        task_id = task_ids[0]
                        progress.update(task_id, description=f"[bold blue]Processing {len(discovered)} discovered devices...[/bold blue]")
                elif isinstance(progress.tasks, list) and len(progress.tasks) > 0:
                    task_id = progress.tasks[0].id
                    progress.update(task_id, description=f"[bold blue]Processing {len(discovered)} discovered devices...[/bold blue]")
            
            # Process discovered devices
            for device in discovered:
                device_info = {
                    'address': device.address,
                    'name': device.name or 'Unknown',
                    'rssi': device.rssi,
                    'metadata': device.metadata,
                    'details': {},
                    'services': [],
                    'manufacturer': self._get_manufacturer_from_metadata(device.metadata),
                    'protocol_version': self._estimate_protocol_version(device.metadata),
                    'signal_strength': device.rssi,
                    'discovery_time': time.time()
                }
                
                # Perform additional analysis for each device if advanced is enabled
                if advanced:
                    device_info['vulnerability_score'] = self._calculate_vulnerability_score(device_info)
                    if progress and hasattr(progress, 'tasks') and progress.tasks:
                        # Handle different progress.tasks types
                        if isinstance(progress.tasks, dict) and progress.tasks:
                            task_ids = list(progress.tasks.keys())
                            if task_ids:  # Make sure the list is not empty
                                task_id = task_ids[0]
                                progress.update(task_id, description=f"[bold blue]Analyzing device: {device_info['name']}[/bold blue]")
                        elif isinstance(progress.tasks, list) and len(progress.tasks) > 0:
                            task_id = progress.tasks[0].id
                            progress.update(task_id, description=f"[bold blue]Analyzing device: {device_info['name']}[/bold blue]")
                    
                    # Try to get service data but don't halt if it fails
                    try:
                        device_info['services'] = await self._get_services(device.address)
                    except Exception as e:
                        self.logger.warning(f"Could not get services for {device.address}: {e}")
                        device_info['services'] = []
                
                self.discovered_devices.append(device_info)
                
        except Exception as e:
            self.logger.error(f"Error in _async_scan: {str(e)}")
            raise
            
# Removed all simulation methods - using real-time scanning only
            
    async def _get_services(self, address):
        """
        Attempt to get services for a device
        
        Args:
            address (str): MAC address of the device
            
        Returns:
            list: Services provided by the device
        """
        try:
            from bleak import BleakClient
            
            services = []
            client = BleakClient(address)
            
            try:
                # Try to connect with short timeout
                if await client.connect(timeout=3.0):
                    # Get services
                    for service in client.services:
                        service_name = str(service.uuid)
                        services.append(service_name)
            except Exception as e:
                self.logger.warning(f"Could not connect to {address} to get services: {e}")
            finally:
                # Make sure to disconnect
                if client.is_connected:
                    await client.disconnect()
                    
            return services
        except Exception as e:
            self.logger.error(f"Error getting services for {address}: {e}")
            return []
    
    def _get_manufacturer_from_metadata(self, metadata):
        """
        Extract manufacturer from device metadata
        
        Args:
            metadata (dict): Device metadata
            
        Returns:
            str: Manufacturer name or "Unknown"
        """
        # Common manufacturer IDs
        manufacturer_ids = {
            0x004C: "Apple",
            0x0075: "Samsung",
            0x0180: "Google",
            0x0059: "Nordic Semiconductor",
            0x0001: "Ericsson",
            0x0002: "Nokia",
            0x0003: "IBM",
            0x0004: "Toshiba",
            0x0006: "Microsoft",
            0x000A: "CSR",
            0x000F: "Broadcom",
            0x00E0: "Google",
            0x008A: "Bose",
            0x0046: "Sony",
            0x0078: "Jabra",
            0x0087: "Garmin",
            0x00E0: "Fitbit"
        }
        
        # Check if metadata is valid and has manufacturer_data as a dictionary
        if isinstance(metadata, dict) and 'manufacturer_data' in metadata:
            # Check if manufacturer_data is a dictionary
            if isinstance(metadata['manufacturer_data'], dict):
                for company_id in metadata['manufacturer_data'].keys():
                    if company_id in manufacturer_ids:
                        return manufacturer_ids[company_id]
        
        # Try to get from local name if available
        if isinstance(metadata, dict) and 'uuids' in metadata:
            # Make sure uuids is an iterable
            if isinstance(metadata['uuids'], (list, tuple, set)):
                for uuid in metadata['uuids']:
                    if isinstance(uuid, str):
                        uuid_lower = uuid.lower()
                        if 'apple' in uuid_lower:
                            return "Apple"
                        elif 'samsung' in uuid_lower:
                            return "Samsung"
                        elif 'google' in uuid_lower:
                            return "Google"
                        elif 'microsoft' in uuid_lower:
                            return "Microsoft"
        
        return "Unknown"
        
    def _estimate_protocol_version(self, metadata):
        """
        Estimate Bluetooth protocol version from device capabilities
        
        Args:
            metadata (dict): Device metadata
            
        Returns:
            str: Estimated protocol version
        """
        # Default to 4.0 as minimum supported
        version = "4.0"
        
        # Check if metadata is valid
        if not isinstance(metadata, dict) or not metadata:
            return version
            
        # Check for BLE 5.0+ features in the advertising data
        if 'manufacturer_data' in metadata and isinstance(metadata['manufacturer_data'], dict):
            # More comprehensive manufacturer data often indicates newer protocols
            if len(metadata['manufacturer_data']) > 2:
                version = "5.0+"
                
        # Check for extended advertising features (5.0+)
        if 'service_data' in metadata and isinstance(metadata['service_data'], dict) and len(metadata['service_data']) > 0:
            version = "5.0+"
            
        # If specific UUIDs are present that indicate newer features
        if 'uuids' in metadata and isinstance(metadata['uuids'], (list, tuple, set)):
            for uuid in metadata['uuids']:
                if not isinstance(uuid, str):
                    continue
                    
                # Audio sharing UUIDs might indicate BT 5.1+
                if uuid.startswith("FE2C"):
                    version = "5.1+"
                # LE audio would indicate 5.2+
                elif uuid.startswith("1853") or uuid.startswith("1854"):
                    version = "5.2+"
                    
        return version
        
    def _calculate_vulnerability_score(self, device_info):
        """
        Calculate a vulnerability score for the device based on known factors
        
        Args:
            device_info (dict): Device information dictionary
            
        Returns:
            float: Vulnerability score (0-10, higher means more vulnerable)
        """
        score = 5.0  # Default mid-range score
        
        # Older protocol versions are more vulnerable
        if 'protocol_version' in device_info:
            version = device_info['protocol_version']
            if version == "4.0":
                score += 3.0
            elif version == "4.1":
                score += 2.5
            elif version == "4.2":
                score += 2.0
            elif version == "5.0" or version == "5.0+":
                score += 1.0
            elif version == "5.1" or version == "5.1+":
                score += 0.5
            elif version == "5.2" or version == "5.2+":
                score += 0.3
            elif version == "5.3" or version == "5.3+":
                score += 0.0
        
        # Signal strength can indicate proximity and thus risk
        if 'signal_strength' in device_info:
            rssi = device_info['signal_strength']
            # Stronger signal means closer device and more vulnerability
            if rssi > -50:  # Very close
                score += 1.0
            elif rssi > -65:  # Close
                score += 0.5
                
        # Certain manufacturers have better security track records
        if 'manufacturer' in device_info:
            manufacturer = device_info['manufacturer']
            if manufacturer == "Apple":
                score -= 0.8
            elif manufacturer == "Microsoft":
                score -= 0.5
            elif manufacturer == "Google":
                score -= 0.6
            elif manufacturer == "Unknown":
                score += 1.0
                
        # Services can indicate vulnerability
        if 'services' in device_info and device_info['services']:
            vulnerable_service_patterns = [
                "1800", # Generic Access - attackable in older versions
                "180F", # Battery Service - information leakage
                "1812", # HID - potentially vulnerable
                "FE59", # Specific vulnerable protocols
            ]
            
            for service in device_info['services']:
                for pattern in vulnerable_service_patterns:
                    if pattern in service:
                        score += 0.7
                        break
                
        # Ensure score stays in range 0-10
        return max(0, min(10, score))
            
    def _display_devices(self):
        """
        Display discovered devices in a rich formatted table
        """
        # Create a rich table
        table = Table(title="RXDSEC Bluetooth Device Scanner - Vulnerability Assessment", 
                     show_header=True, header_style="bold red")
        
        # Add columns
        table.add_column("ID", style="cyan", justify="center", width=3)
        table.add_column("Device Name", style="green", width=25)
        table.add_column("MAC Address", style="blue", width=18)
        table.add_column("RSSI", style="magenta", justify="center", width=6)
        table.add_column("Version", style="yellow", justify="center", width=7)
        table.add_column("Vulnerability", style="red", justify="center", width=15)
        
        # Add device rows
        for idx, device in enumerate(self.discovered_devices):
            # Get vulnerability score with proper formatting
            vuln_score = device.get('vulnerability_score', None)
            if vuln_score is not None:
                # Color-code based on vulnerability severity
                if vuln_score >= 8.0:
                    vuln_text = f"[bold red]{vuln_score:.1f}/10 CRITICAL"
                elif vuln_score >= 6.0:
                    vuln_text = f"[red]{vuln_score:.1f}/10 HIGH"
                elif vuln_score >= 4.0:
                    vuln_text = f"[yellow]{vuln_score:.1f}/10 MEDIUM"
                else:
                    vuln_text = f"[green]{vuln_score:.1f}/10 LOW"
            else:
                vuln_text = "[dim]N/A"
            
            # Get signal strength with proper formatting
            signal = device.get('signal_strength', None)
            if signal is not None:
                if signal > -50:
                    signal_text = f"[bold green]{signal}"  # Very strong
                elif signal > -65:
                    signal_text = f"[green]{signal}"       # Strong
                elif signal > -80:
                    signal_text = f"[yellow]{signal}"      # Medium
                else:
                    signal_text = f"[red]{signal}"         # Weak
            else:
                signal_text = "[dim]N/A"
                
            # Add the row to the table
            table.add_row(
                str(idx),
                device['name'][:25],
                device['address'],
                signal_text,
                device.get('protocol_version', "Unknown"),
                vuln_text
            )
        
        # Display the table
        self.console.print(table)
        
        # Display additional attack information
        if self.discovered_devices:
            most_vulnerable = max(self.discovered_devices, 
                                  key=lambda d: d.get('vulnerability_score', 0) 
                                  if isinstance(d.get('vulnerability_score'), (int, float)) else 0)
            vuln_score = most_vulnerable.get('vulnerability_score', 0)
            
            if vuln_score >= 6.0:
                self.console.print(Panel(
                    f"[bold red]HIGH VULNERABILITY DETECTED: {most_vulnerable['name']} ({most_vulnerable['address']})\n"
                    f"Vulnerability Score: {vuln_score:.1f}/10\n"
                    f"Protocol Version: {most_vulnerable.get('protocol_version', 'Unknown')}\n"
                    f"Signal Strength: {most_vulnerable.get('signal_strength', 'Unknown')}\n"
                    f"Recommended: Select this device for targeted attack operations."
                ))
        
    def cleanup(self):
        """
        Clean up scanner resources and stop any active operations
        """
        self.logger.info("Cleaning up Bluetooth scanner resources")
        self.scanning_active = False
        
        # Clean up async resources if they exist
        if self.loop and hasattr(self.loop, 'is_running') and self.loop.is_running():
            # Running in the main thread?
            if self.loop is asyncio.get_event_loop() and self.loop.is_running():
                # Can't close a running event loop, so just note it
                self.logger.info("Event loop still running, can't close")
            else:
                try:
                    self.loop.close()
                except Exception as e:
                    self.logger.warning(f"Error closing event loop: {e}")
        
        # Clear the device list
        self.discovered_devices = []
        
        return True