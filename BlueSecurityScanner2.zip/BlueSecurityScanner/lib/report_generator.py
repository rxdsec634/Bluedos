import os
import sys
import time
import logging
import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.markdown import Markdown

class ReportGenerator:
    """
    Generates detailed security reports based on analysis results
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.console = Console()
        self.simulation_mode = True
        
    def generate_report(self, analysis_results):
        """
        Generate a comprehensive security report from analysis results
        
        Args:
            analysis_results (dict): Dictionary of device analysis results
        """
        try:
            if not analysis_results:
                self.console.print("[yellow]No analysis results to generate report from[/yellow]")
                return
                
            self.console.print("[bold blue]Generating security report...[/bold blue]")
            
            # Create reports directory if it doesn't exist
            os.makedirs("reports", exist_ok=True)
            
            # Generate timestamp for report filename
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # Generate report for each analyzed device
            for addr, results in analysis_results.items():
                # Skip incomplete analysis
                if not results.get('analysis_complete', False):
                    continue
                    
                # Generate filename
                device_name = results['device_info']['name'].replace(' ', '_')
                filename = f"reports/bt_security_report_{device_name}_{timestamp}.txt"
                
                # Generate and save report
                self._generate_device_report(addr, results, filename)
                
                # Display report in console
                self._display_console_report(addr, results)
                
            self.console.print(f"[green]Report(s) saved to reports directory[/green]")
            
        except Exception as e:
            self.logger.error(f"Error in generate_report: {str(e)}")
            self.console.print(f"[bold red]Error generating report: {str(e)}[/bold red]")
            
    def _generate_device_report(self, addr, results, filename):
        """
        Generate a report for a specific device
        
        Args:
            addr (str): MAC address of the device
            results (dict): Analysis results for the device
            filename (str): Path to save the report
        """
        device = results['device_info']
        
        try:
            with open(filename, 'w') as f:
                # Write report header
                f.write("===========================================================\n")
                f.write("           BLUETOOTH DEVICE SECURITY ANALYSIS REPORT        \n")
                f.write("===========================================================\n\n")
                
                # Write device information
                f.write("DEVICE INFORMATION:\n")
                f.write(f"Name: {device['name']}\n")
                f.write(f"MAC Address: {addr}\n")
                f.write(f"Protocol Version: {device.get('protocol_version', 'Unknown')}\n")
                f.write(f"Manufacturer: {device.get('manufacturer', 'Unknown')}\n")
                f.write(f"Analysis Date: {datetime.datetime.fromtimestamp(results['timestamp']).strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                # Write security rating
                rating = results['security_rating']
                rating_description = self._get_security_rating_description(rating)
                f.write("SECURITY RATING:\n")
                f.write(f"{rating:.1f}/10 - {rating_description}\n\n")
                
                # Write PIN security analysis
                f.write("PIN SECURITY:\n")
                pin_security = results.get('pin_security', {})
                f.write(f"Common PINs Accepted: {'Yes' if pin_security.get('common_pins_accepted', False) else 'No'}\n")
                f.write(f"PIN Complexity: {pin_security.get('pin_complexity', 'Unknown')}\n")
                f.write(f"Minimum PIN Length: {pin_security.get('min_pin_length', 'Unknown')}\n")
                f.write(f"Uses Legacy Pairing: {'Yes' if pin_security.get('uses_legacy_pairing', False) else 'No'}\n")
                f.write(f"Supports Secure Simple Pairing: {'Yes' if pin_security.get('supports_ssp', False) else 'No'}\n")
                f.write(f"Security Level: {pin_security.get('security_level', 'Unknown')}\n\n")
                
                # Write encryption analysis
                f.write("ENCRYPTION:\n")
                encryption = results.get('encryption', {})
                f.write(f"Supports E0 Cipher: {'Yes' if encryption.get('supports_e0', False) else 'No'}\n")
                f.write(f"Supports AES-CCM: {'Yes' if encryption.get('supports_aes_ccm', False) else 'No'}\n")
                f.write(f"Minimum Key Size: {encryption.get('min_key_size', 'Unknown')} bytes\n")
                f.write(f"Maximum Key Size: {encryption.get('max_key_size', 'Unknown')} bytes\n")
                f.write(f"Encryption Enforced: {'Yes' if encryption.get('encryption_enforced', False) else 'No'}\n")
                f.write(f"Security Level: {encryption.get('security_level', 'Unknown')}\n\n")
                
                # Write authentication analysis
                f.write("AUTHENTICATION:\n")
                authentication = results.get('authentication', {})
                f.write(f"Supports Legacy Authentication: {'Yes' if authentication.get('supports_legacy_auth', False) else 'No'}\n")
                f.write(f"Supports Secure Simple Pairing: {'Yes' if authentication.get('supports_ssp', False) else 'No'}\n")
                f.write(f"Supports Out of Band Pairing: {'Yes' if authentication.get('supports_oob', False) else 'No'}\n")
                f.write(f"Supports Numeric Comparison: {'Yes' if authentication.get('supports_numeric_comparison', False) else 'No'}\n")
                f.write(f"MITM Protection: {'Yes' if authentication.get('mitm_protection', False) else 'No'}\n")
                f.write(f"Secure Connections: {'Yes' if authentication.get('secure_connections', False) else 'No'}\n")
                f.write(f"Security Level: {authentication.get('security_level', 'Unknown')}\n\n")
                
                # Write L2CAP vulnerabilities
                f.write("L2CAP VULNERABILITIES:\n")
                l2cap_vulns = results.get('l2cap_vulnerabilities', [])
                if l2cap_vulns:
                    for vuln in l2cap_vulns:
                        f.write(f"- {vuln.get('name', 'Unknown')}\n")
                        f.write(f"  Severity: {vuln.get('severity', 'Unknown')}\n")
                        f.write(f"  Description: {vuln.get('description', 'No description')}\n")
                        f.write(f"  CVE Reference: {vuln.get('cve_reference', 'Unknown')}\n\n")
                else:
                    f.write("No L2CAP vulnerabilities detected\n\n")
                    
                # Write vulnerabilities
                f.write("VULNERABILITIES:\n")
                vulnerabilities = results.get('vulnerabilities', [])
                if vulnerabilities:
                    for i, vuln in enumerate(vulnerabilities):
                        f.write(f"{i+1}. {vuln.get('name', 'Unknown')}\n")
                        f.write(f"   Category: {vuln.get('category', 'Unknown')}\n")
                        f.write(f"   Severity: {vuln.get('severity', 'Unknown')}\n")
                        f.write(f"   Description: {vuln.get('description', 'No description')}\n")
                        
                        if 'cve_reference' in vuln:
                            f.write(f"   CVE Reference: {vuln.get('cve_reference', 'Unknown')}\n")
                            
                        f.write("\n")
                else:
                    f.write("No vulnerabilities detected\n\n")
                    
                # Write recommendations
                f.write("SECURITY RECOMMENDATIONS:\n")
                if vulnerabilities:
                    self._write_recommendations(f, results)
                else:
                    f.write("No specific recommendations - device appears secure\n")
                    
                # Write footer
                f.write("\n===========================================================\n")
                f.write("                    END OF REPORT                           \n")
                f.write("===========================================================\n")
                
        except Exception as e:
            self.logger.error(f"Error in _generate_device_report: {str(e)}")
            self.console.print(f"[bold red]Error writing report to {filename}: {str(e)}[/bold red]")
            
    def _display_console_report(self, addr, results):
        """
        Display a formatted report on the console
        
        Args:
            addr (str): MAC address of the device
            results (dict): Analysis results for the device
        """
        device = results['device_info']
        
        # Create device info panel
        device_info = f"[bold]Name:[/bold] {device['name']}\n"
        device_info += f"[bold]MAC Address:[/bold] {addr}\n"
        device_info += f"[bold]Protocol Version:[/bold] {device.get('protocol_version', 'Unknown')}\n"
        device_info += f"[bold]Manufacturer:[/bold] {device.get('manufacturer', 'Unknown')}"
        
        info_panel = Panel(device_info, title="Device Information", border_style="blue")
        self.console.print(info_panel)
        
        # Display security rating
        rating = results['security_rating']
        if rating >= 7.0:
            rating_color = "green"
        elif rating >= 4.0:
            rating_color = "yellow"
        else:
            rating_color = "red"
            
        rating_description = self._get_security_rating_description(rating)
        
        rating_panel = Panel(
            f"[bold {rating_color}]{rating:.1f}/10[/bold {rating_color}]\n{rating_description}",
            title="Security Rating",
            border_style=rating_color
        )
        self.console.print(rating_panel)
        
        # Display vulnerability summary
        vulnerabilities = results.get('vulnerabilities', [])
        
        if vulnerabilities:
            vuln_count = len(vulnerabilities)
            high_count = sum(1 for v in vulnerabilities if v.get('severity') == "High")
            medium_count = sum(1 for v in vulnerabilities if v.get('severity') == "Medium")
            low_count = sum(1 for v in vulnerabilities if v.get('severity') == "Low")
            
            vuln_summary = f"[bold]Total Vulnerabilities:[/bold] {vuln_count}\n"
            vuln_summary += f"[bold red]High Severity:[/bold red] {high_count}\n"
            vuln_summary += f"[bold yellow]Medium Severity:[/bold yellow] {medium_count}\n"
            vuln_summary += f"[bold green]Low Severity:[/bold green] {low_count}"
            
            vuln_panel = Panel(vuln_summary, title="Vulnerability Summary", border_style="red")
            self.console.print(vuln_panel)
            
            # Create table of vulnerabilities
            table = Table(title="Security Vulnerabilities")
            table.add_column("#", style="cyan")
            table.add_column("Category", style="magenta")
            table.add_column("Vulnerability", style="red")
            table.add_column("Severity", style="yellow")
            table.add_column("Description")
            
            for i, vuln in enumerate(vulnerabilities):
                severity = vuln.get('severity', 'Unknown')
                severity_color = "red" if severity == "High" else "yellow" if severity == "Medium" else "green"
                
                table.add_row(
                    str(i+1),
                    vuln.get('category', 'Unknown'),
                    vuln.get('name', 'Unknown'),
                    f"[{severity_color}]{severity}[/{severity_color}]",
                    vuln.get('description', 'No description')
                )
                
            self.console.print(table)
            
            # Display recommendations
            self.console.print("\n[bold yellow]Security Recommendations:[/bold yellow]")
            self._print_recommendations(results)
        else:
            self.console.print("[bold green]No vulnerabilities detected[/bold green]")
            
    def _get_security_rating_description(self, rating):
        """
        Get a description of the security rating
        
        Args:
            rating (float): Security rating (1-10)
            
        Returns:
            str: Description of the security rating
        """
        if rating >= 9.0:
            return "Excellent - Device implements strong security measures with no significant vulnerabilities"
        elif rating >= 7.0:
            return "Good - Device has strong security with minor potential vulnerabilities"
        elif rating >= 5.0:
            return "Moderate - Device has acceptable security but some concerning vulnerabilities"
        elif rating >= 3.0:
            return "Poor - Device has significant security weaknesses that should be addressed"
        else:
            return "Critical - Device has severe security vulnerabilities that make it unsafe for sensitive use"
            
    def _write_recommendations(self, file, results):
        """
        Write security recommendations to the report file
        
        Args:
            file: File object to write to
            results (dict): Analysis results
        """
        vulnerabilities = results.get('vulnerabilities', [])
        
        # Get recommendations from vulnerabilities
        recommendations = []
        for vuln in vulnerabilities:
            if 'recommendation' in vuln and vuln['recommendation'] not in recommendations:
                recommendations.append(vuln['recommendation'])
                
        # Write recommendations
        if recommendations:
            for i, rec in enumerate(recommendations):
                file.write(f"{i+1}. {rec}\n")
        else:
            # Generic recommendations if no specific ones
            file.write("1. Keep the device firmware updated to the latest version\n")
            file.write("2. Use strong, unique PINs when pairing new devices\n")
            file.write("3. Disable Bluetooth when not in use to reduce attack surface\n")
            
    def _print_recommendations(self, results):
        """
        Print security recommendations to the console
        
        Args:
            results (dict): Analysis results
        """
        vulnerabilities = results.get('vulnerabilities', [])
        
        # Get recommendations from vulnerabilities
        recommendations = []
        for vuln in vulnerabilities:
            if 'recommendation' in vuln and vuln['recommendation'] not in recommendations:
                recommendations.append(vuln['recommendation'])
                
        # Print recommendations
        if recommendations:
            for i, rec in enumerate(recommendations):
                self.console.print(f"{i+1}. {rec}")
        else:
            # Generic recommendations if no specific ones
            self.console.print("1. Keep the device firmware updated to the latest version")
            self.console.print("2. Use strong, unique PINs when pairing new devices")
            self.console.print("3. Disable Bluetooth when not in use to reduce attack surface")