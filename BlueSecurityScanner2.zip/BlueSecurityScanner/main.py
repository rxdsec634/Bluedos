import os
import sys
import time
import logging
from colorama import init, Fore, Back, Style
from lib.scanner import BluetoothScanner
from lib.analyzer import SecurityAnalyzer
from lib.packet_crafter import PacketCrafter
from lib.report_generator import ReportGenerator
from lib.utils import print_banner, setup_logging, check_bluetooth_service, check_root_privileges, print_warning, print_info, print_error

# Initialize colorama for cross-platform colored terminal text
init(autoreset=True)

class BluetoothToolkit:
    def __init__(self):
        self.scanner = BluetoothScanner()
        self.analyzer = SecurityAnalyzer()
        self.packet_crafter = PacketCrafter()
        self.report_generator = ReportGenerator()
        # Setup logging
        setup_logging()
        self.logger = logging.getLogger(__name__)
        # Real-time Bluetooth scanning mode
        self.simulation_mode = False
        print_info("Running in REAL-TIME SCAN mode - searching for actual Bluetooth devices")

    def main_menu(self):
        # Check for root privileges (simulation)
        if not check_root_privileges():
            print_warning("This tool requires root privileges for full functionality")
            if input("Continue with limited functionality? (y/n): ").lower() != 'y':
                sys.exit(1)

        # Check Bluetooth service (simulation)
        if not check_bluetooth_service():
            print_warning("Bluetooth service is not running")
            if input("Attempt to start Bluetooth service? (y/n): ").lower() == 'y':
                if not check_bluetooth_service():
                    print_warning("Failed to start Bluetooth service. Some features may not work.")
            else:
                print_warning("Some features may not work without Bluetooth service.")

        while True:
            print_banner()
            print(Style.BRIGHT + Fore.WHITE + "=== MAIN MENU ===" + Style.RESET_ALL)
            print(Fore.BLUE + "1. " + Style.BRIGHT + "[SCAN]" + Style.RESET_ALL + Fore.BLUE + " Real-time Bluetooth device scanner" + Style.RESET_ALL)
            print(Fore.YELLOW + "2. " + Style.BRIGHT + "[ANALYZE]" + Style.RESET_ALL + Fore.YELLOW + " Execute comprehensive security analysis" + Style.RESET_ALL)
            print(Fore.RED + "3. " + Style.BRIGHT + "[ATTACK]" + Style.RESET_ALL + Fore.RED + " Launch advanced attack operations" + Style.RESET_ALL)
            print(Fore.GREEN + "4. " + Style.BRIGHT + "[REPORT]" + Style.RESET_ALL + Fore.GREEN + " Generate detailed penetration report" + Style.RESET_ALL)
            print(Fore.LIGHTBLACK_EX + "5. " + Style.BRIGHT + "[EXIT]" + Style.RESET_ALL + Fore.LIGHTBLACK_EX + " Exit toolkit" + Style.RESET_ALL)

            choice = input("\nSelect an option: ")

            try:
                if choice == "1":
                    self.scanner.scan_devices()
                elif choice == "2":
                    if not self.scanner.discovered_devices:
                        print_warning("Please scan for devices first")
                        continue
                    self.analyze_device()
                elif choice == "3":
                    if not self.scanner.discovered_devices:
                        print_warning("Please scan for devices first")
                        continue
                    self.packet_operations()
                elif choice == "4":
                    if not self.analyzer.analysis_results:
                        print_warning("Please perform analysis first")
                        continue
                    self.report_generator.generate_report(self.analyzer.analysis_results)
                elif choice == "5":
                    print("\n" + Fore.YELLOW + "[!] Shutting down RXDSEC toolkit..." + Style.RESET_ALL)
                    print(Fore.YELLOW + "[!] Cleaning up resources..." + Style.RESET_ALL)
                    # Clean up any active resources or connections
                    if hasattr(self.scanner, 'cleanup'):
                        self.scanner.cleanup()
                    if hasattr(self.packet_crafter, 'cleanup'):
                        self.packet_crafter.cleanup()
                    print(Fore.GREEN + "[+] All resources released successfully" + Style.RESET_ALL)
                    print(Fore.GREEN + "[+] RXDSEC toolkit exited safely" + Style.RESET_ALL)
                    sys.exit(0)
                else:
                    print_error("Invalid option")
            except Exception as e:
                self.logger.error(f"Error in main menu: {str(e)}")
                print_error(f"Error: {str(e)}")

    def analyze_device(self):
        print("\n" + Style.BRIGHT + Fore.YELLOW + "=== SECURITY ANALYSIS TARGET SELECTION ===" + Style.RESET_ALL)
        for idx, device in enumerate(self.scanner.discovered_devices):
            name = device['name'] if device['name'] else 'Unknown Device'
            print(f"{Fore.YELLOW}{idx}. {Style.BRIGHT}{name}{Style.RESET_ALL} {Fore.LIGHTBLACK_EX}({device['address']}){Style.RESET_ALL}")
        
        try:
            device_idx = int(input("\n" + Fore.WHITE + "Enter device number: " + Style.RESET_ALL))
            if 0 <= device_idx < len(self.scanner.discovered_devices):
                target_device = self.scanner.discovered_devices[device_idx]
                print(Fore.GREEN + f"[+] Analyzing device: {target_device['name']}" + Style.RESET_ALL)
                self.analyzer.analyze_device(target_device)
            else:
                print_error("Invalid device selection")
        except ValueError:
            print_error("Please enter a valid number")

    def packet_operations(self):
        print("\n" + Style.BRIGHT + Fore.WHITE + "=== ADVANCED ATTACK OPERATIONS ===" + Style.RESET_ALL)
        print(Fore.YELLOW + "1. " + Style.BRIGHT + "[VULN SCAN]" + Style.RESET_ALL + Fore.YELLOW + " Identify L2CAP protocol vulnerabilities" + Style.RESET_ALL)
        print(Fore.RED + "2. " + Style.BRIGHT + "[PIN CRACK]" + Style.RESET_ALL + Fore.RED + " Attack pairing & security mechanisms" + Style.RESET_ALL)
        print(Fore.RED + "3. " + Style.BRIGHT + "[AUTH BYPASS]" + Style.RESET_ALL + Fore.RED + " Target authentication vulnerabilities" + Style.RESET_ALL)
        print(Fore.RED + "4. " + Style.BRIGHT + "[ULTRA DOS]" + Style.RESET_ALL + Fore.RED + " Launch high-power DoS attack (15K+ packets/sec)" + Style.RESET_ALL)
        print(Fore.LIGHTBLACK_EX + "5. " + Style.BRIGHT + "[BACK]" + Style.RESET_ALL + Fore.LIGHTBLACK_EX + " Return to main menu" + Style.RESET_ALL)

        try:
            op_choice = input("\nSelect operation: ")
            
            if op_choice == "5":
                return
                
            if op_choice not in ["1", "2", "3", "4"]:
                print_error("Invalid operation selection")
                return
                
            # Select target device
            target_device = self.select_target_device()
            if not target_device:
                return
                
            # Perform selected operation
            if op_choice == "1":
                self.packet_crafter.perform_operation("l2cap_vuln", target_device)
            elif op_choice == "2":
                self.packet_crafter.perform_operation("pin_security", target_device)
            elif op_choice == "3":
                self.packet_crafter.perform_operation("auth", target_device)
            elif op_choice == "4":
                # DoS attack needs special handling
                self.packet_crafter.perform_operation("dos_attack", target_device)
                
        except Exception as e:
            self.logger.error(f"Error in packet_operations: {str(e)}")
            print_error(f"Error: {str(e)}")

    def select_target_device(self):
        print("\n" + Style.BRIGHT + Fore.CYAN + "=== SELECT TARGET DEVICE ===" + Style.RESET_ALL)
        for idx, device in enumerate(self.scanner.discovered_devices):
            name = device['name'] if device['name'] else 'Unknown Device'
            print(f"{Fore.CYAN}{idx}. {Style.BRIGHT}{name}{Style.RESET_ALL} {Fore.LIGHTBLACK_EX}({device['address']}){Style.RESET_ALL}")
        
        try:
            device_idx = int(input("\n" + Fore.WHITE + "Enter device number: " + Style.RESET_ALL))
            if 0 <= device_idx < len(self.scanner.discovered_devices):
                print(Fore.GREEN + f"[+] Selected device: {self.scanner.discovered_devices[device_idx]['name']}" + Style.RESET_ALL)
                return self.scanner.discovered_devices[device_idx]
            else:
                print_error("Invalid device selection")
                return None
        except ValueError:
            print_error("Please enter a valid number")
            return None

if __name__ == "__main__":
    toolkit = BluetoothToolkit()
    toolkit.main_menu()